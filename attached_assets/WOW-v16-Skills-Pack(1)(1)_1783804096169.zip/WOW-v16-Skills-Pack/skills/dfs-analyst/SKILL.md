# DFS Analyst

**Skill ID:** `wow.dfs-analyst`  
**Version:** `1.0.0`  
**Owner:** WOW v16 Clean Core  
**Execution:** Decision support only

## Purpose
Models salary-cap DFS projections, ownership, leverage, correlation, and contest-specific lineup risk.

## Invoke when
Use this skill whenever the requested analysis materially depends on its domain. The orchestrator may invoke it automatically, but it must not duplicate another skill's authoritative responsibility.

## Inputs
- Canonical event and market identifiers
- Requested date/time and timezone
- Available prices, lines, projections, statistics, statuses, or source URLs
- Active WOW patches and Reliability Freeze state
- Upstream skill results when applicable

## Required operations
1. Slate identity.
2. Projection and minutes.
3. Salary value.
4. Ownership/leverage.
5. Stack correlation.
6. Contest type.
7. Portfolio exposure.

## Output contract
Set `can_execute=false` in every result. Return structured JSON matching `schemas/skill-result.schema.json`, plus a concise human-readable summary. Every probability, edge, or adjustment must expose its formula or provenance.

## Label rules
- `READY` only when all mandatory identity, freshness, provenance, and domain gates pass.
- `WATCH` for credible analysis with one non-fatal limitation.
- `SCOUT` for early discovery or insufficient confirmation.
- `HOLD` when a required final recheck is pending.
- `REJECT_BAD_RULES` for invalid market/settlement/structure.
- `REJECT_DATA_QUALITY` for contradictions or unusable evidence.
- `DATA_UNOBTAINABLE` when required data cannot be fetched or verified.

## Hard bans
- No invented inputs or timestamps.
- No upgrading operator-supplied evidence to direct/live.
- No bypassing active WOW/LLP gates.
- No execution or order placement.
- No certainty language unsupported by calibrated probability.

## Handoff
State which downstream skill should consume the result and include machine-readable blockers. The orchestrator, not this skill, owns the final cross-domain decision.
