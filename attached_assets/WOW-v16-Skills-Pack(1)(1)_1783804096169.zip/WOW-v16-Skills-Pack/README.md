# WOW v16 Clean Core Skills Pack

This pack contains **21 deployable skill specifications** plus a shared contract, orchestrator, JSON schema, acceptance tests, and a Replit implementation prompt.

## Install concept
Copy the `skills/` folders into the project skill directory, load `skill-registry.json`, and implement adapters against existing WOW engines. Do not replace working engines with prompt-only logic.

## Recommended first implementation wave
1. Sports Research Analyst
2. Market & Odds Intelligence
3. Player Prop Intelligence
4. Game Script Simulator
5. Probability & EV Auditor
6. Correlation & Slip Auditor
7. Kalshi Contract Intelligence
8. QA & Hallucination Auditor
9. Patch Governance Manager
10. Bankroll & Risk Manager

The remaining skills can be wired after the shared contracts and orchestrator are stable.

## Files
- `SHARED_CONTRACT.md`
- `ORCHESTRATOR.md`
- `skill-registry.json`
- `schemas/skill-result.schema.json`
- `REPLIT_IMPLEMENTATION_PROMPT.md`
- `tests/acceptance-tests.md`
- `skills/*/SKILL.md`
