# WOW v16 Skill Orchestrator

## Canonical execution sequence
1. Sports Research Analyst: slate, identity, status, lineup/starter, teammate context.
2. Historical Trend Researcher and league specialist(s): trusted baseline and role/regime segmentation.
3. Player Prop / MLB / WNBA / DFS specialist: domain projection.
4. Game Script Simulator: scenario survival and script-adjusted probability.
5. Weather and Referee/Umpire skills when applicable.
6. Market & Odds Intelligence: current same-market pricing and no-vig.
7. Probability & EV Auditor: calibrated probability, breakeven, friction, EV.
8. Correlation & Slip Auditor: structure, duplicates, joint probability, exposure.
9. Kalshi Contract Intelligence for Kalshi only: settlement/orderbook/freshness/dry-run fill.
10. Bankroll & Risk Manager: sizing only after all eligibility gates; never for blocked capital lanes.
11. QA & Hallucination Auditor: final fail-closed review.
12. Patch Governance Manager: invoked for rule changes, conflicts, regressions, or new patches.

## Routing rules
- Team winners/totals/spreads: Sports Research -> league specialist -> Game Script -> Market/Odds -> Probability/EV -> Risk -> QA.
- Player props: Sports Research -> Player Prop + league specialist -> Game Script -> Market/Odds -> Probability/EV -> Correlation -> Risk -> QA.
- Kalshi sports: Run health first. `INVENTORY_EMPTY` stops the workflow. Otherwise add Kalshi Contract Intelligence after model probability and before risk.
- Kalshi weather: Weather -> Probability/EV -> Kalshi Contract -> QA. Capital allocation remains blocked until ledger milestone requirements pass.
- Lottery: Lottery -> QA. Never route to Market/Odds or Risk as if predictive edge were guaranteed.

## Final decision ownership
The orchestrator may only output the lowest ceiling produced by any mandatory skill. A downstream skill cannot erase an upstream blocker.
