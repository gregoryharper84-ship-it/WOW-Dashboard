# WOW v14.9 — Tier 0 NBA (stats.nba.com)

## What's new
- **Flask `/nba-stats/gamelog`** route — pulls real per-game NBA stats from
  stats.nba.com via the `nba_api` library. Free, current-season data,
  independent of API-Sports plan status.
- **HTML `fetchNBAStatsGamelog(name)`** helper — calls the new endpoint and
  caches results per player.
- **`runFlaskBasketballEngine` wiring** — for NBA candidates, tries
  stats.nba.com FIRST. Falls back to api-sports gamelog (currently blocked),
  then to synthetic season-avg with the honest SEASON AVG badge.

## NBA candidates now show
- Real PTS/REB/AST/STL/BLK from the player's last 10 actual games
- `data_quality: 'gamelog-real'` (not `'season-avg'`)
- No yellow SEASON AVG badge

## WNBA still shows SEASON AVG badge
- stats.wnba.com and data.wnba.com both block Replit's egress IPs (timeout / 403)
- WNBA stays on the honest synthetic display until you can either
  (a) unsuspend API-Sports, or
  (b) route WNBA traffic through a residential proxy

## Files
- `app.py` — new route at line ~4814
- `index.html` — new helper at L3366, engine change at L3443
- `requirements.txt` — adds `nba_api>=1.4.0`
