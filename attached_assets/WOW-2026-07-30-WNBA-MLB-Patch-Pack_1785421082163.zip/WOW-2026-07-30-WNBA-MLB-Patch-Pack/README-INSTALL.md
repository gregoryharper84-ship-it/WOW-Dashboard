# WOW 2026-07-30 WNBA/MLB Patch Pack

## Included Files

1. `wow-wnba-composite-prop-expert-SKILL.md`
   - New WNBA joint P/R/A and stat-family selection skill.

2. `wow-cross-ticket-exposure-governor-SKILL.md`
   - New multi-card duplicate and shared-thesis governor.

3. `wow-mlb-pitcher-failure-path-expert-SKILL-v2.md`
   - Existing failure-path expert plus K LESS directional firewall, outs survival gate, and cross-ticket integration.

4. `wow-slip-probability-optimizer-SKILL-v3.md`
   - Existing optimizer plus WNBA routing, MLB directional routing, unique-observation calibration, and cross-ticket governance.

5. `WOW-PATCH-2026-07-30-WNBA-COMPOSITE-MLB-DIRECTIONAL-AND-CROSS-TICKET-GOVERNANCE.md`
   - Controlling patch document.

6. `WOW-REGRESSION-TESTS-2026-07-30.md`
   - Prompt-level and implementation-level regression tests.

## Installation Split

### WOW Betting Engine Custom GPT

Upload all six Markdown files to the GPT knowledge files.

Use the activation prompt from the patch document in the GPT instructions or at the start of a session.

### Replit Engine

Implement the enforceable state and ledger pieces:

```text
WNBA_COMPOSITE_FORWARD_TEST
MLB_K_LESS_WATCH_ONLY
MLB_OUTS_MORE_HOLD_CEILING
unique_underlying_thesis_key
duplicate_group_id
cross_ticket_fragility
directional_pitcher_ledger
WNBA_unique_player_game_ledger
```

The Custom GPT should reason and audit. Replit should persist state, deduplicate rows, enforce ceilings, and run regression tests.

## Master Activation Prompt

> Load WOW v16 Clean Core. Activate WOW-PATCH-2026-07-30-WNBA-COMPOSITE-MLB-DIRECTIONAL-AND-CROSS-TICKET-GOVERNANCE, wow.wnba-composite-prop-expert, wow.mlb-pitcher-failure-path-expert v2, wow.slip-probability-optimizer v3, and wow.cross-ticket-exposure-governor. Compare all verified WNBA P/R/A component and composite lines through a role-conditioned joint distribution, keep MLB K LESS at WATCH_ONLY and MLB outs MORE at a workload-survival HOLD ceiling, deduplicate exact and latent player/pitcher theses across every card, grade unique theses separately from financial exposure, write all settled rows to their forward-test ledgers, and enforce can_execute=false.
