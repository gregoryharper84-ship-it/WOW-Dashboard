# Integration

1. Register NBA/WNBA, MLB hitter, MLB pitcher, and NFL Fantasy Score routes.
2. Reconstruct each role-matched game's Fantasy Score from existing component logs.
3. Keep formula versions immutable inside an L5/L10 cohort.
4. Score both MORE and LESS with the Gaussian CDF.
5. Apply calibration and small-sample haircuts; never upgrade from uncertainty.
6. Store predictions before event start and outcomes separately.
7. Track Brier score, log loss, ECE, and calibration bias by sport/formula/direction.
8. Reject same-player, same-event Fantasy Score plus any weighted component as `LEG_REJECT_DUPLICATE_THESIS`.
9. Add the shared thesis key to cross-slip exposure accounting.
10. Keep NFL blocked until the reception coefficient is verified.
11. Keep every provisional Fantasy Score row Power-ineligible and no higher than `MODEL_QUALIFIED_HOLD`.
