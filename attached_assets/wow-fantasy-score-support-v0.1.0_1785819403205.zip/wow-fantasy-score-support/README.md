# WOW Fantasy Score Support

Research-only implementation for deterministic Fantasy Score reconstruction, a first-pass Gaussian probability model, calibration logging, and component/composite correlation protection.

```text
can_execute=false
lane_status=PROVISIONAL
maximum_ceiling=MODEL_QUALIFIED_HOLD
```

The exact Task #84 formula table was not available in the supplied files, so production coefficients are not silently invented. `config/fantasy_score_formulas.json` is fail-closed with `verified=false`. Populate the official coefficients, source, and timestamp before scoring. NFL remains blocked until the reception weight is verified.

Install and test:

```bash
python -m pip install -e .[dev]
pytest
```
