import json
from wow_fantasy_score import FormulaRegistry, FantasyScoreModel, PropRequest, CorrelationGuard, PropLeg, CalibrationLedger

def test_unverified_formula_fails_closed(tmp_path):
    p = tmp_path/"f.json"
    p.write_text(json.dumps({"sports":{"NBA":{"version":"v1","verified":False,"source":None,"retrieved_at":None,"coefficients":{"PTS":1}}}}))
    result = FantasyScoreModel(FormulaRegistry.from_json(p)).score(
        PropRequest("NBA","A",20.5,"MORE",[{"PTS":10}]*5))
    assert result.terminal_label == "REJECT_DATA_QUALITY"
    assert result.raw_probability is None

def test_verified_formula_scores(tmp_path):
    p = tmp_path/"f.json"
    p.write_text(json.dumps({"sports":{"NBA":{"version":"v1","verified":True,"source":"official","retrieved_at":"2026-08-03T12:00:00Z","coefficients":{"PTS":1,"REB":1}}}}))
    rows=[{"PTS":20+i,"REB":5+(i%3)} for i in range(10)]
    result = FantasyScoreModel(FormulaRegistry.from_json(p)).score(
        PropRequest("NBA","A",29.5,"MORE",rows))
    assert result.raw_probability is not None
    assert abs(result.raw_probability + result.opposite_probability - 1) < 1e-9

def test_component_composite_block():
    a=PropLeg("1","NBA","LeBron James","LAL-GSW","Points","MORE",27.5)
    b=PropLeg("2","NBA","LeBron James","LAL-GSW","Fantasy Score","MORE",49.5)
    result=CorrelationGuard().evaluate_pair(a,b)
    assert result.blocked
    assert result.label=="LEG_REJECT_DUPLICATE_THESIS"

def test_calibration_metrics():
    m=CalibrationLedger.metrics([(0.8,1),(0.7,1),(0.6,0),(0.4,0)])
    assert m["count"]==4
    assert 0 <= m["brier_score"] <= 1
